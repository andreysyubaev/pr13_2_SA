﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Student
    {
        private string name;
        private string surname;
        private int bookname = 0;

        public Student(string name, string surname, int bookname)
        {
            this.name = name;
            this.surname = surname;
            this.bookname = bookname;
        }

        public string GetName()
        {
            return name;
        }

        public string GetSurname()
        {
            return surname;
        }

        public int GetBookname()
        {
            return bookname;
        }
    }



}
